import React, { useEffect, useMemo, useState } from "react";
import "./App.css";
/**
 * Notes:
 * - This React app works standalone in the browser (simulates launch/stop).
 * - If you wrap with Electron and expose window.electronAPI.startApp/stopApp in preload.js,
 *   it will actually launch and kill the chosen executable for the purchased duration.
 */

// ===== Schedule (you can edit freely) =====
const schedule = [
  { day: "Monday", time: "11:00 - 12:00", class: "CML102" },
  { day: "Monday", time: "17:00 - 18:30", class: "PYL749" },
  { day: "Tuesday", time: "08:00 - 09:00", class: "PYL209" },
  { day: "Tuesday", time: "17:00 - 18:00", class: "PYL759" },
  { day: "Wednesday", time: "08:00 - 09:00", class: "PYL209" },
  { day: "Wednesday", time: "11:00 - 12:00", class: "CML102" },
  { day: "Wednesday", time: "12:00 - 13:00", class: "PYL759" },
  { day: "Thursday", time: "12:00 - 13:00", class: "CML102" },
  { day: "Thursday", time: "17:00 - 18:30", class: "PYL749" },
  { day: "Friday", time: "08:00 - 09:00", class: "PYL209" },
  { day: "Friday", time: "17:00 - 18:00", class: "PYL759" },
];

// ===== Coin rules =====
const COINS_TO_MINUTES = {
  game: 15,   // 1 coin -> 15 mins gameplay
  music: 30,  // 1 coin -> 30 mins music
  p: 5,       // 1 coin -> 5 mins P
};

// Helper to read/write JSON in localStorage safely
const readLS = (k, fallback) => {
  try {
    const v = localStorage.getItem(k);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
};

const writeLS = (k, v) => localStorage.setItem(k, JSON.stringify(v));

export default function App() {
  // ===== Core time & storage =====
  const [now, setNow] = useState(new Date());

  // Modal state - moved inside component
  const [modal, setModal] = useState({ open: false, category: null, coins: 1 });

  const [coins, setCoins] = useState(() => {
    const raw = localStorage.getItem("coins");
    return raw ? parseFloat(raw) : 0;
  });
  const [history, setHistory] = useState(() => readLS("history", []));

  // App registries by category
  const [gameApps, setGameApps] = useState(() => readLS("gameApps", []));   // [{name, path}]
  const [musicApps, setMusicApps] = useState(() => readLS("musicApps", [])); // [{name, path}]
  const [pApps, setPApps] = useState(() => readLS("pApps", []));             // [{name, path}]

  // Selected app IDs per category for launching
  const [selectedGameId, setSelectedGameId] = useState("");
  const [selectedMusicId, setSelectedMusicId] = useState("");
  const [selectedPId, setSelectedPId] = useState("");

  // Active session (only one at a time)
  const [activeSession, setActiveSession] = useState(() => readLS("activeSession", null));
  const hasElectron = typeof window !== "undefined" && window.electronAPI;

  // Tickers
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // Persist key states
  useEffect(() => localStorage.setItem("coins", String(coins)), [coins]);
  useEffect(() => writeLS("history", history), [history]);
  useEffect(() => writeLS("gameApps", gameApps), [gameApps]);
  useEffect(() => writeLS("musicApps", musicApps), [musicApps]);
  useEffect(() => writeLS("pApps", pApps), [pApps]);
  useEffect(() => writeLS("activeSession", activeSession), [activeSession]);

  // ===== Helpers =====
  const addHistory = (entry) => {
    setHistory((prev) => [{ ...entry, id: crypto.randomUUID?.() || Date.now() }, ...prev]);
  };

  const addCoins = (amount, reason) => {
    setCoins((c) => c + amount);
    addHistory({ type: "earn", reason, amount, ts: Date.now() });
  };

  const spendCoins = (amount, reason) => {
    if (coins < amount) {
      alert("Not enough coins!");
      return false;
    }
    setCoins((c) => c - amount);
    addHistory({ type: "spend", reason, amount, ts: Date.now() });
    return true;
  };

  const totals = useMemo(() => {
    let earned = 0, spent = 0;
    for (const h of history) {
      if (h.type === "earn") earned += Number(h.amount) || 0;
      if (h.type === "spend") spent += Number(h.amount) || 0;
    }
    return { earned, spent };
  }, [history]);

  // ===== Earn buttons =====
  const earnLeetCode = (difficulty, helpUsed) => {
    const base = difficulty === "easy" ? 1 : difficulty === "medium" ? 2 : 3;
    const amount = helpUsed ? base / 2 : base;
    addCoins(amount, `LeetCode ${difficulty}${helpUsed ? " (help)" : ""}`);
  };

  const earnHackathon = () => {
    const hoursStr = prompt("How many hours did you work? (1 coin per hour)");
    const hours = Number(hoursStr || "0");
    if (hours > 0) addCoins(hours, `Hackathon/Self-study: ${hours}h`);
  };

  // ===== Manage registered apps =====
  const addAppToList = (type) => {
    // Create a hidden input and let user pick an executable (Electron exposes file.path)
    const input = document.createElement("input");
    input.type = "file";
    input.onchange = (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const app = {
        id: crypto.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        name: file.name,
        // In Electron renderer, file.path is available. In browser it's not (security).
        // We still store name so you can see it in the list; path is needed only in Electron mode.
        path: file.path || file.name,
      };
      if (type === "game") setGameApps((l) => [...l, app]);
      if (type === "music") setMusicApps((l) => [...l, app]);
      if (type === "p") setPApps((l) => [...l, app]);
    };
    input.click();
  };

  const removeAppFromList = (type, id) => {
    if (type === "game") setGameApps((l) => l.filter((a) => a.id !== id));
    if (type === "music") setMusicApps((l) => l.filter((a) => a.id !== id));
    if (type === "p") setPApps((l) => l.filter((a) => a.id !== id));
  };

  // ===== Launch / stop logic =====
  const startTimedSession = async (category, coinsToSpend, app) => {
    // Compute minutes from coins
    const perCoin = COINS_TO_MINUTES[category];
    const totalMinutes = perCoin * coinsToSpend;
    if (totalMinutes <= 0) return;

    const ok = spendCoins(coinsToSpend, `${category.toUpperCase()} - ${app?.name || "Unknown app"} (${totalMinutes}m)`);
    if (!ok) return;

    // Stop any ongoing session first
    if (activeSession && hasElectron) {
      try { await window.electronAPI.stopApp(); } catch {}
    }

    const endsAt = Date.now() + totalMinutes * 60 * 1000;
    const session = {
      category,
      appId: app?.id || null,
      appName: app?.name || "",
      appPath: app?.path || "",
      startedAt: Date.now(),
      endsAt,
    };
    setActiveSession(session);

    // Ask Electron to launch
    if (hasElectron && app?.path) {
      try {
        await window.electronAPI.startApp({
          filePath: app.path,
          durationMinutes: totalMinutes,
        });
      } catch (e) {
        console.error(e);
        alert("Failed to start the app via Electron.");
      }
    }
  };

  const stopSession = async (reason = "Stopped") => {
    if (!activeSession) return;
    if (hasElectron) {
      try { await window.electronAPI.stopApp(); } catch {}
    }
    addHistory({
      type: "info",
      reason: `Session ended: ${activeSession.category.toUpperCase()} - ${activeSession.appName} (${reason})`,
      amount: 0,
      ts: Date.now(),
    });
    setActiveSession(null);
  };

  // Auto-expire watcher - removed the eslint disable comment
  useEffect(() => {
    if (!activeSession) return;
    const tick = setInterval(() => {
      if (Date.now() >= activeSession.endsAt) {
        clearInterval(tick);
        stopSession("Time expired");
      }
    }, 1000);
    return () => clearInterval(tick);
  }, [activeSession?.endsAt]); // Added proper dependency

  // Remaining time
  const remaining = useMemo(() => {
    if (!activeSession) return null;
    const ms = Math.max(0, activeSession.endsAt - Date.now());
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  }, [now, activeSession]);

  // UI handlers for starting sessions with dropdown selection and coins input
  const askCoinsAndStart = (category) => {
    const map = { game: gameApps, music: musicApps, p: pApps };
    const list = map[category] || [];
    if (!list.length) {
      alert(`No ${category} apps added yet.`);
      return;
    }
    setModal({ open: true, category, coins: 1 });
  };

  const startFromModal = () => {
    const { category, coins } = modal;
    const map = { game: gameApps, music: musicApps, p: pApps };
    const list = map[category] || [];
    const selectedId =
      category === "game" ? selectedGameId :
      category === "music" ? selectedMusicId :
      selectedPId;

    const app = list.find((a) => a.id === selectedId) || list[0];
    startTimedSession(category, Number(coins), app);
    setModal({ open: false, category: null, coins: 1 });
  };

  return (
    <div className="App">
      <header className="app-bar">
        <h1>Life Simulator</h1>
        <div className="clock">Current Time: {now.toLocaleTimeString()}</div>
      </header>

      <section className="stats">
        <div className="stat">
          <div className="label">Coins</div>
          <div className="value">{coins.toFixed(1)}</div>
        </div>
        <div className="stat">
          <div className="label">Total Earned</div>
          <div className="value">+{totals.earned.toFixed(1)}</div>
        </div>
        <div className="stat">
          <div className="label">Total Spent</div>
          <div className="value">-{totals.spent.toFixed(1)}</div>
        </div>
        <div className="stat">
          <div className="label">Electron</div>
          <div className={`value ${hasElectron ? "ok" : "warn"}`}>
            {hasElectron ? "Detected" : "Browser-only"}
          </div>
        </div>
      </section>

      {/* Earn */}
      <section className="card">
        <h2>Earn Coins</h2>
        <div className="buttons">
          <button onClick={() => earnLeetCode("easy", false)}>LeetCode Easy (1)</button>
          <button onClick={() => earnLeetCode("easy", true)}>LeetCode Easy (0.5, help)</button>
          <button onClick={() => earnLeetCode("medium", false)}>LeetCode Medium (2)</button>
          <button onClick={() => earnLeetCode("medium", true)}>LeetCode Medium (1, help)</button>
          <button onClick={() => earnLeetCode("hard", false)}>LeetCode Hard (3)</button>
          <button onClick={() => earnLeetCode("hard", true)}>LeetCode Hard (1.5, help)</button>
          <button onClick={earnHackathon}>Hackathon / Self-study (1 coin/hour)</button>
        </div>
      </section>

      {/* Manage Apps */}
      <section className="card">
        <h2>Manage Apps</h2>
        <div className="apps-grid">
          {/* Games */}
          <div className="apps-col">
            <div className="apps-header">
              <h3>Games</h3>
              <button className="outline" onClick={() => addAppToList("game")}>+ Add Game</button>
            </div>
            <select
              value={selectedGameId}
              onChange={(e) => setSelectedGameId(e.target.value)}
            >
              {gameApps.length === 0 && <option value="">No games added</option>}
              {gameApps.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
            <ul className="apps-list">
              {gameApps.map((g) => (
                <li key={g.id}>
                  <span title={g.path}>{g.name}</span>
                  <button className="tiny danger" onClick={() => removeAppFromList("game", g.id)}>remove</button>
                </li>
              ))}
            </ul>
          </div>

          {/* Music */}
          <div className="apps-col">
            <div className="apps-header">
              <h3>Music</h3>
              <button className="outline" onClick={() => addAppToList("music")}>+ Add Music App</button>
            </div>
            <select
              value={selectedMusicId}
              onChange={(e) => setSelectedMusicId(e.target.value)}
            >
              {musicApps.length === 0 && <option value="">No music apps added</option>}
              {musicApps.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
            <ul className="apps-list">
              {musicApps.map((m) => (
                <li key={m.id}>
                  <span title={m.path}>{m.name}</span>
                  <button className="tiny danger" onClick={() => removeAppFromList("music", m.id)}>remove</button>
                </li>
              ))}
            </ul>
          </div>

          {/* P stuff */}
          <div className="apps-col">
            <div className="apps-header">
              <h3>Porn Stuff</h3>
              <button className="outline" onClick={() => addAppToList("p")}>+ Add App</button>
            </div>
            <select
              value={selectedPId}
              onChange={(e) => setSelectedPId(e.target.value)}
            >
              {pApps.length === 0 && <option value="">No apps added</option>}
              {pApps.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            <ul className="apps-list">
              {pApps.map((p) => (
                <li key={p.id}>
                  <span title={p.path}>{p.name}</span>
                  <button className="tiny danger" onClick={() => removeAppFromList("p", p.id)}>remove</button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Spend coins / Start sessions */}
      <section className="card">
        <h2>Spend Coins (launch & auto-close)</h2>

        <div className="spend-row">
          <div className="spend-block">
            <div className="label">Gameplay</div>
            <div className="sub">1 coin = 15 mins</div>
            <button onClick={() => askCoinsAndStart("game")}>Start Gameplay</button>
          </div>
          <div className="spend-block">
            <div className="label">Music</div>
            <div className="sub">1 coin = 30 mins</div>
            <button onClick={() => askCoinsAndStart("music")}>Start Music</button>
          </div>
          <div className="spend-block">
            <div className="label">P Stuff</div>
            <div className="sub">1 coin = 5 mins</div>
            <button onClick={() => askCoinsAndStart("p")}>Start P Session</button>
          </div>
        </div>

        {activeSession ? (
          <div className="active-session">
            <div>
              <strong>Active:</strong> {activeSession.category.toUpperCase()} — {activeSession.appName || "Unknown"}
            </div>
            <div>Remaining: <span className="mono">{remaining}</span></div>
            <button className="danger" onClick={() => stopSession("Manual stop")}>Stop Now</button>
          </div>
        ) : (
          <div className="muted">No active session</div>
        )}
      </section>

      {/* Weekly schedule */}
      <section className="card">
        <h2>Weekly Schedule</h2>
        <div className="schedule">
          {schedule.map((item, i) => (
            <div key={i} className="schedule-row">
              <strong>{item.day}</strong>
              <span>{item.time}</span>
              <span>{item.class}</span>
            </div>
          ))}
        </div>
      </section>

      {/* History */}
      <section className="card">
        <h2>History</h2>
        <div className="history">
          {history.length === 0 && <div className="muted">No history yet</div>}
          {history.map((h) => (
            <div key={h.id} className={`hist ${h.type}`}>
              <span className="ts">{new Date(h.ts).toLocaleTimeString()}</span>
              {h.type === "earn" && <span className="plus">+{h.amount}</span>}
              {h.type === "spend" && <span className="minus">-{h.amount}</span>}
              {h.type === "info" && <span className="info">•</span>}
              <span className="reason">{h.reason}</span>
            </div>
          ))}
        </div>
      </section>
  
      {modal.open && (
        <div className="modal-backdrop">
          <div className="modal">
            <h3>
              Spend Coins for {modal.category.toUpperCase()}
            </h3>
            <p>1 coin = {COINS_TO_MINUTES[modal.category]} mins</p>
            <input
              type="number"
              min="1"
              value={modal.coins}
              onChange={(e) => setModal({ ...modal, coins: e.target.value })}
            />
            <div className="modal-actions">
              <button onClick={startFromModal}>Start</button>
              <button onClick={() => setModal({ open: false, category: null, coins: 1 })}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <footer className="muted small">
        Tip: In Electron, expose <code>window.electronAPI.startApp/stopApp</code> in preload.js to actually launch/close the selected exe.
      </footer>
    </div>
  );
}